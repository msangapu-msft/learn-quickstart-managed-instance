﻿<%@ Application Codebehind="Global.asax.cs" Inherits="AptosImageDemo.Global" Language="C#" %>
